import React, { useState, useEffect, useMemo } from 'react';
import { AreaChart, Area, LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Legend, ComposedChart } from 'recharts';

// ===================== COMPREHENSIVE DATA FROM FINAL CAPSTONE =====================
const WEII_PILLARS = [
  { id: 'wildlife', name: 'Wildlife Status', weight: 50, icon: '🦁', subIndices: [
    { name: 'Wildlife Assets', weight: 25, desc: 'Species richness, population trends, habitat integrity' },
    { name: 'Conservation Effectiveness', weight: 25, desc: 'Protected area coverage, management quality, threat mitigation' }
  ]},
  { id: 'investment', name: 'Investment Environment', weight: 50, icon: '💼', subIndices: [
    { name: 'Ease of Business', weight: 12.5, desc: 'Regulatory framework, business processes, market access' },
    { name: 'Public Sector Capacity', weight: 12.5, desc: 'Institutional strength, governance, coordination' },
    { name: 'Investment Safety', weight: 12.5, desc: 'Political stability, rule of law, risk factors' },
    { name: 'Wildlife Management', weight: 12.5, desc: 'Policy frameworks, enforcement, community integration' }
  ]}
];

const COUNTRIES = {
  southAfrica: {
    name: 'South Africa', flag: '🇿🇦', region: 'Southern Africa', rank: 1,
    weiiScore: 63.12, // Actual WEII score from ALU data
    debtToGDP: 74.0, protectedArea: 8.9, gdpGrowth: 0.9,
    marketReadiness: 78, legalFramework: 82, institutionalCapacity: 75,
    lionPop: 3284, buffaloPop: 46000, rhinoPop: 16000,
    highlights: [
      'Climate Change Act (2024) enacted',
      'Rhino Bond achieved 8% growth (2x target)',
      'Green Finance Taxonomy operational',
      'SANBI as potential MRV verifier',
      'JSE Sustainability Segment active'
    ],
    challenges: ['74% debt-to-GDP ratio', 'Coalition government uncertainty', 'Energy constraints'],
    keyLaws: ['PFMA 1999', 'NEMA 1998', 'NBF 2019-2024', 'Climate Change Act 2024'],
    scores: { wildlife: 58, management: 74.92, business: 65, capacity: 70, safety: 68 },
    bondPotential: { size: 500, couponBase: 8.5, stepDown: 25, stepUp: 25 }
  },
  tanzania: {
    name: 'Tanzania', flag: '🇹🇿', region: 'East Africa', rank: 4,
    weiiScore: 52.8, // Estimated from species richness leadership
    debtToGDP: 43.5, protectedArea: 38, gdpGrowth: 5.1,
    marketReadiness: 62, legalFramework: 58, institutionalCapacity: 55,
    lionPop: 17000, buffaloPop: 225000, rhinoPop: 180,
    highlights: [
      'Africa\'s largest lion population (17,000)',
      'Africa\'s largest buffalo population (225,000)',
      '38% land under protection',
      'CRDB Kijani Bond ($300M) issued 2023',
      'NMB Green Bond ($168M) active'
    ],
    challenges: ['Fragmented legal framework', 'Limited MRV capacity', 'Data system gaps'],
    keyLaws: ['Gov Loans Act 1974', 'FYDP III 2021-2026', 'NBSAP II', 'EMA 2004'],
    scores: { wildlife: 43.94, management: 62, business: 48, capacity: 52, safety: 55 },
    bondPotential: { size: 500, couponBase: 7.0, stepDown: 25, stepUp: 25 }
  }
};

const BENCHMARK_DEALS = [
  { name: 'Wildlife Conservation Bond', nickname: 'Rhino Bond', issuer: 'World Bank', country: '🇿🇦 South Africa', year: 2022, size: 150, type: 'Outcome-Based', icon: '🦏', 
    kpi: 'Black rhino population growth', target: '4% annual', achieved: '8% (2x target)', verifier: 'Zoological Society of London', 
    status: 'Exceeding', mechanism: 'GEF-funded success payment', hectares: 154000, lessons: 'Outcome-based structures work when metrics are clear' },
  { name: 'Gabon Blue Bond', issuer: 'Republic of Gabon', country: '🇬🇦 Gabon', year: 2023, size: 500, type: 'Debt-for-Nature Swap', icon: '🌊',
    kpi: 'Marine protected area expansion', target: '30% ocean by 2030', achieved: 'On track', verifier: 'The Nature Conservancy',
    status: 'Active', mechanism: 'Credit enhancement via US DFC', hectares: 0, lessons: 'DFI guarantees unlock larger deals' },
  { name: 'Ecuador Galápagos Conversion', issuer: 'Republic of Ecuador', country: '🇪🇨 Ecuador', year: 2023, size: 1600, type: 'Debt-for-Nature Swap', icon: '🐢',
    kpi: 'Hermandad Marine Reserve', target: '6M hectare reserve', achieved: 'Created', verifier: 'TNC/Pew',
    status: 'Success', mechanism: 'Credit Suisse + IDB guarantee', hectares: 6000000, lessons: 'Largest conservation debt swap in history' },
  { name: 'Uruguay SSLB', issuer: 'Republic of Uruguay', country: '🇺🇾 Uruguay', year: 2022, size: 1500, type: 'Sustainability-Linked', icon: '🌿',
    kpi: 'GHG reduction + native forest', target: '-50% emissions, +4% forest', achieved: 'In progress', verifier: 'Sustainalytics',
    status: 'Active', mechanism: '±15bp coupon adjustment', hectares: 0, lessons: 'First sovereign SLB - 4x oversubscribed' },
  { name: 'Bahamas Blue Bond', issuer: 'Commonwealth of Bahamas', country: '🇧🇸 Bahamas', year: 2024, size: 300, type: 'Debt-for-Nature Swap', icon: '🐠',
    kpi: 'Marine conservation funding', target: 'Ongoing protection', achieved: 'Active', verifier: 'TNC',
    status: 'Active', mechanism: 'IDB + DFC structure', hectares: 0, lessons: 'Expanding to terrestrial in 2025' }
];

const MARKET_DATA_2025 = {
  biodiversityGap: 700, // $700B annually
  sustainableDebtMarket: 1700, // $1.7T+
  privateNatureFinance: 102, // $102B in circulation (2024)
  debtSwapPipeline: 800, // $500-800B potential
  biofin2025: 2700, // $2.7B unlocked by BIOFIN
  rhinoBondReturn: 8, // 8% actual vs 4% target
  natureBondsUnlocked: 1400, // $1.4B by Debt for Nature Coalition
  hectaresProtected: 242 // 242M hectares committed
};

const FIVE_PILLAR_FRAMEWORK = [
  { pillar: 1, name: 'Legal & Policy Codification', icon: '⚖️', status: 'Feasible', 
    tz: 'Gov Loans Act permits - needs MoU', za: 'PFMA + NEMA sufficient',
    action: 'Draft performance covenants in debt documentation' },
  { pillar: 2, name: 'Institutional Coordination', icon: '🏛️', status: 'Required',
    tz: 'WEII Steering Committee needed', za: 'Working group with SANBI',
    action: 'Establish inter-ministerial oversight body' },
  { pillar: 3, name: 'Market Instrument Design', icon: '📊', status: 'Ready',
    tz: '±25bp coupon model tested', za: 'JSE infrastructure available',
    action: 'Structure pilot term sheets with DFI support' },
  { pillar: 4, name: 'MRV Architecture', icon: '✓', status: 'In Development',
    tz: 'TAWIRI baseline + capacity building', za: 'SANBI + SEEA alignment',
    action: 'Align with TNFD, ICMA, CBD reporting' },
  { pillar: 5, name: 'Reform Roadmap', icon: '🗺️', status: 'Designed',
    tz: '6-month phased approach', za: 'Integration with Green Taxonomy',
    action: 'Sequence legal → institutional → market → launch' }
];

const IMPLEMENTATION_PHASES = [
  { phase: 1, name: 'Legal & Policy Diagnostic', months: '1-2', budget: 15000, 
    deliverables: ['Comparative legal analysis', 'Gap matrix', 'Reform recommendations'],
    status: 'Completed', progress: 100 },
  { phase: 2, name: 'Institutional Readiness', months: '2-3', budget: 16000,
    deliverables: ['Capacity scorecards', 'Coordination blueprint', 'Steering Committee ToR'],
    status: 'Completed', progress: 100 },
  { phase: 3, name: 'Market & ESG Mapping', months: '3-4', budget: 17000,
    deliverables: ['Investor landscape', 'Private sector matrix', 'De-risking options'],
    status: 'Completed', progress: 100 },
  { phase: 4, name: 'MRV Framework Design', months: '4-5', budget: 13000,
    deliverables: ['Verification protocol', 'KPI definitions', 'Dashboard prototype'],
    status: 'Completed', progress: 100 },
  { phase: 5, name: 'Roadmap & Pilot Design', months: '5-6', budget: 15000,
    deliverables: ['Reform agenda', 'Prototype term sheets', 'Investor pitch'],
    status: 'Completed', progress: 100 }
];

const RISKS = [
  { id: 1, name: 'Political/Governance Shifts', category: 'Political', likelihood: 'Medium', impact: 'High',
    mitigation: 'High-level endorsement, cross-party briefings, international anchoring via DFI guarantees',
    contingency: 'External commitment devices create reputational costs for withdrawal' },
  { id: 2, name: 'Data/Verification Gaps', category: 'Technical', likelihood: 'High', impact: 'High',
    mitigation: 'Conservative KPIs, independent verification (ZSL model), TNFD alignment',
    contingency: 'Substitution clauses for unmeasurable indicators' },
  { id: 3, name: 'Market/Investor Uncertainty', category: 'Financial', likelihood: 'Medium', impact: 'High',
    mitigation: 'Anchor investors early, partial credit guarantees, ICMA-aligned structure',
    contingency: 'Standard SLB mechanics to reduce novelty premium' },
  { id: 4, name: 'Community Non-Participation', category: 'Social', likelihood: 'Medium', impact: 'Medium',
    mitigation: 'FPIC protocols, benefit-sharing KPIs, grievance mechanisms',
    contingency: 'Namibia CBNRM model as proof of community gains' },
  { id: 5, name: 'Macro/FX Volatility', category: 'Economic', likelihood: 'Medium', impact: 'Medium',
    mitigation: 'Local currency pegging, inflation buffers, 15% contingency',
    contingency: 'Conservative exchange assumptions, deferral provisions' }
];

const STAKEHOLDERS = [
  { name: 'Ministry of Finance', country: 'TZ', influence: 95, interest: 90, category: 'Government', role: 'Debt issuance authority' },
  { name: 'National Treasury', country: 'SA', influence: 95, interest: 88, category: 'Government', role: 'Sovereign debt management' },
  { name: 'DFFE', country: 'SA', influence: 85, interest: 95, category: 'Government', role: 'Biodiversity policy lead' },
  { name: 'VPO Environment', country: 'TZ', influence: 80, interest: 92, category: 'Government', role: 'Conservation policy' },
  { name: 'SANBI', country: 'SA', influence: 75, interest: 90, category: 'Technical', role: 'MRV verifier candidate' },
  { name: 'ESG Investors', country: 'Global', influence: 80, interest: 85, category: 'Private', role: 'Capital providers' },
  { name: 'World Bank', country: 'Global', influence: 85, interest: 80, category: 'DFI', role: 'Technical assistance + guarantees' },
  { name: 'TNC/Conservation NGOs', country: 'Global', influence: 70, interest: 95, category: 'NGO', role: 'Technical support + advocacy' },
  { name: 'Local Communities', country: 'Both', influence: 40, interest: 95, category: 'Beneficiary', role: 'FPIC + benefit recipients' },
  { name: 'Rating Agencies', country: 'Global', influence: 85, interest: 60, category: 'Market', role: 'Credit assessment' }
];

// ===================== COLOR PALETTE =====================
const c = {
  primary: '#1a5f3c', primaryLight: '#2d8f5c', primaryDark: '#0d3d25',
  accent: '#c9a227', accentLight: '#e8c547', accentDark: '#9a7a0f',
  bg: '#0f1419', bgCard: '#1a2332', bgCardHover: '#243042', border: '#2d3d4f',
  text: '#e8edf5', textMuted: '#8899aa', textDim: '#556677',
  success: '#00c853', warning: '#ff9500', danger: '#ff3b30', info: '#007aff',
  chart1: '#00c853', chart2: '#c9a227', chart3: '#007aff', chart4: '#ff9500'
};

const catColors = {
  Government: c.primary, Technical: c.info, Private: c.accent, DFI: '#8b5cf6', NGO: '#ec4899', Beneficiary: c.success, Market: c.warning
};

// ===================== UTILITY COMPONENTS =====================
const Card = ({ children, className = '', hover = true, glow = false, style = {} }) => (
  <div style={{
    background: c.bgCard, border: `1px solid ${c.border}`, borderRadius: 16,
    transition: 'all 0.3s ease', boxShadow: glow ? `0 0 30px ${c.primary}30` : 'none', ...style
  }} className={className}>{children}</div>
);

const Badge = ({ children, type = 'default', size = 'sm' }) => {
  const colors = {
    high: { bg: `${c.danger}20`, color: c.danger }, medium: { bg: `${c.warning}20`, color: c.warning },
    low: { bg: `${c.success}20`, color: c.success }, success: { bg: `${c.success}20`, color: c.success },
    active: { bg: `${c.info}20`, color: c.info }, completed: { bg: `${c.success}20`, color: c.success },
    feasible: { bg: `${c.success}20`, color: c.success }, required: { bg: `${c.warning}20`, color: c.warning },
    ready: { bg: `${c.info}20`, color: c.info }, 'in development': { bg: `${c.warning}20`, color: c.warning },
    designed: { bg: `${c.success}20`, color: c.success }, exceeding: { bg: `${c.success}20`, color: c.success },
    default: { bg: `${c.textDim}20`, color: c.textMuted }
  };
  const s = colors[type.toLowerCase()] || colors.default;
  return <span style={{ display: 'inline-block', padding: size === 'sm' ? '3px 10px' : '5px 14px',
    background: s.bg, color: s.color, borderRadius: 20, fontSize: size === 'sm' ? 11 : 13, fontWeight: 600,
    textTransform: 'uppercase', letterSpacing: '0.05em' }}>{children}</span>;
};

const SectionHeader = ({ label, title, subtitle, align = 'center' }) => (
  <div style={{ textAlign: align, maxWidth: 900, margin: align === 'center' ? '0 auto 50px' : '0 0 50px 0' }}>
    <div style={{ fontSize: 11, fontWeight: 700, color: c.accent, textTransform: 'uppercase', letterSpacing: '0.25em', marginBottom: 12 }}>{label}</div>
    <h2 style={{ fontSize: 'clamp(1.5rem, 3.5vw, 2.25rem)', fontWeight: 700, color: c.text, marginBottom: 14, lineHeight: 1.2 }}>{title}</h2>
    {subtitle && <p style={{ fontSize: 16, color: c.textMuted, lineHeight: 1.7 }}>{subtitle}</p>}
  </div>
);

const StatBox = ({ value, label, trend, color = c.text, small = false }) => (
  <div style={{ textAlign: 'center', padding: small ? 12 : 20 }}>
    <div style={{ fontSize: small ? 24 : 32, fontWeight: 700, color, marginBottom: 4 }}>{value}</div>
    <div style={{ fontSize: small ? 10 : 12, color: c.textMuted, textTransform: 'uppercase', letterSpacing: '0.05em' }}>{label}</div>
    {trend && <div style={{ fontSize: 11, color: trend > 0 ? c.success : c.danger, marginTop: 4 }}>{trend > 0 ? '↑' : '↓'} {Math.abs(trend)}%</div>}
  </div>
);

const ProgressRing = ({ value, size = 120, strokeWidth = 10, color = c.success }) => {
  const radius = (size - strokeWidth) / 2;
  const circ = radius * 2 * Math.PI;
  const offset = circ - (value / 100) * circ;
  return (
    <div style={{ position: 'relative', width: size, height: size }}>
      <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
        <circle cx={size/2} cy={size/2} r={radius} fill="none" stroke={c.border} strokeWidth={strokeWidth} />
        <circle cx={size/2} cy={size/2} r={radius} fill="none" stroke={color} strokeWidth={strokeWidth}
          strokeLinecap="round" strokeDasharray={circ} strokeDashoffset={offset} style={{ transition: 'stroke-dashoffset 1s ease' }} />
      </svg>
      <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
        <span style={{ fontSize: size * 0.25, fontWeight: 700, color }}>{value.toFixed(1)}</span>
        <span style={{ fontSize: size * 0.1, color: c.textMuted }}>WEII</span>
      </div>
    </div>
  );
};

// ===================== INVESTOR BOND CALCULATOR =====================
const BondCalculator = () => {
  const [country, setCountry] = useState('tanzania');
  const [principal, setPrincipal] = useState(500);
  const [tenor, setTenor] = useState(10);
  const [weiiImprovement, setWeiiImprovement] = useState(5);
  
  const data = COUNTRIES[country];
  const { couponBase, stepDown, stepUp } = data.bondPotential;
  
  const scenarioMet = couponBase - (stepDown / 100);
  const scenarioMissed = couponBase + (stepUp / 100);
  const observationYear = Math.floor(tenor / 2);
  
  const annualSavings = (principal * (stepDown / 10000));
  const totalSavings = annualSavings * (tenor - observationYear);
  const annualPenalty = (principal * (stepUp / 10000));
  const totalPenalty = annualPenalty * (tenor - observationYear);
  
  const conservationFunding = totalSavings * 0.8; // 80% to conservation
  
  return (
    <Card style={{ padding: 32 }}>
      <h3 style={{ fontSize: 20, fontWeight: 700, color: c.text, marginBottom: 24, display: 'flex', alignItems: 'center', gap: 10 }}>
        <span style={{ fontSize: 24 }}>🧮</span> WEII-Linked Bond Calculator
      </h3>
      
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 20, marginBottom: 32 }}>
        <div>
          <label style={{ fontSize: 12, color: c.textMuted, display: 'block', marginBottom: 8 }}>Issuing Country</label>
          <select value={country} onChange={e => setCountry(e.target.value)} style={{ width: '100%', padding: 12, background: c.bg, border: `1px solid ${c.border}`, borderRadius: 8, color: c.text, fontSize: 14 }}>
            <option value="tanzania">🇹🇿 Tanzania</option>
            <option value="southAfrica">🇿🇦 South Africa</option>
          </select>
        </div>
        <div>
          <label style={{ fontSize: 12, color: c.textMuted, display: 'block', marginBottom: 8 }}>Principal (USD M)</label>
          <input type="number" value={principal} onChange={e => setPrincipal(+e.target.value)} style={{ width: '100%', padding: 12, background: c.bg, border: `1px solid ${c.border}`, borderRadius: 8, color: c.text, fontSize: 14 }} />
        </div>
        <div>
          <label style={{ fontSize: 12, color: c.textMuted, display: 'block', marginBottom: 8 }}>Tenor (Years)</label>
          <input type="number" value={tenor} onChange={e => setTenor(+e.target.value)} min={5} max={30} style={{ width: '100%', padding: 12, background: c.bg, border: `1px solid ${c.border}`, borderRadius: 8, color: c.text, fontSize: 14 }} />
        </div>
        <div>
          <label style={{ fontSize: 12, color: c.textMuted, display: 'block', marginBottom: 8 }}>Projected WEII Improvement (%)</label>
          <input type="number" value={weiiImprovement} onChange={e => setWeiiImprovement(+e.target.value)} style={{ width: '100%', padding: 12, background: c.bg, border: `1px solid ${c.border}`, borderRadius: 8, color: c.text, fontSize: 14 }} />
        </div>
      </div>
      
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16, marginBottom: 24 }}>
        <Card style={{ padding: 20, background: c.bg, textAlign: 'center' }}>
          <div style={{ fontSize: 11, color: c.textMuted, marginBottom: 8 }}>BASE COUPON</div>
          <div style={{ fontSize: 28, fontWeight: 700, color: c.text }}>{couponBase.toFixed(2)}%</div>
        </Card>
        <Card style={{ padding: 20, background: `${c.success}10`, border: `1px solid ${c.success}40`, textAlign: 'center' }}>
          <div style={{ fontSize: 11, color: c.success, marginBottom: 8 }}>IF KPIs MET (↓{stepDown}bp)</div>
          <div style={{ fontSize: 28, fontWeight: 700, color: c.success }}>{scenarioMet.toFixed(2)}%</div>
        </Card>
        <Card style={{ padding: 20, background: `${c.danger}10`, border: `1px solid ${c.danger}40`, textAlign: 'center' }}>
          <div style={{ fontSize: 11, color: c.danger, marginBottom: 8 }}>IF KPIs MISSED (↑{stepUp}bp)</div>
          <div style={{ fontSize: 28, fontWeight: 700, color: c.danger }}>{scenarioMissed.toFixed(2)}%</div>
        </Card>
      </div>
      
      <div style={{ background: c.bg, borderRadius: 12, padding: 24, marginBottom: 24 }}>
        <h4 style={{ fontSize: 14, fontWeight: 600, color: c.text, marginBottom: 16 }}>Fiscal Impact Analysis (Year {observationYear} observation)</h4>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 24 }}>
          <div>
            <div style={{ fontSize: 12, color: c.textMuted, marginBottom: 4 }}>Annual Debt Service Savings (if met)</div>
            <div style={{ fontSize: 24, fontWeight: 700, color: c.success }}>${annualSavings.toFixed(2)}M</div>
          </div>
          <div>
            <div style={{ fontSize: 12, color: c.textMuted, marginBottom: 4 }}>Total Savings (Years {observationYear+1}-{tenor})</div>
            <div style={{ fontSize: 24, fontWeight: 700, color: c.success }}>${totalSavings.toFixed(2)}M</div>
          </div>
          <div>
            <div style={{ fontSize: 12, color: c.textMuted, marginBottom: 4 }}>Conservation Funding (80%)</div>
            <div style={{ fontSize: 24, fontWeight: 700, color: c.accent }}>${conservationFunding.toFixed(2)}M</div>
          </div>
          <div>
            <div style={{ fontSize: 12, color: c.textMuted, marginBottom: 4 }}>Potential Penalty (if missed)</div>
            <div style={{ fontSize: 24, fontWeight: 700, color: c.danger }}>${totalPenalty.toFixed(2)}M</div>
          </div>
        </div>
      </div>
      
      <div style={{ padding: 16, background: `${c.accent}15`, borderRadius: 8, borderLeft: `4px solid ${c.accent}` }}>
        <div style={{ fontSize: 13, color: c.accent, fontWeight: 600, marginBottom: 4 }}>💡 Investment Insight</div>
        <div style={{ fontSize: 13, color: c.textMuted }}>
          A {weiiImprovement}% WEII improvement would trigger coupon step-down, generating ${totalSavings.toFixed(1)}M in fiscal savings 
          that can be earmarked for conservation trust funds, community benefit schemes, and habitat protection.
        </div>
      </div>
    </Card>
  );
};

// ===================== MARKET OPPORTUNITY SECTION =====================
const MarketOpportunity = () => {
  const marketData = [
    { name: '2020', private: 9.4, sovereign: 50, gap: 700 },
    { name: '2022', private: 45, sovereign: 150, gap: 700 },
    { name: '2024', private: 102, sovereign: 500, gap: 700 },
    { name: '2025', private: 150, sovereign: 800, gap: 700 },
    { name: '2030P', private: 500, sovereign: 2000, gap: 700 }
  ];
  
  return (
    <section style={{ padding: '80px 24px', background: `linear-gradient(180deg, ${c.bg} 0%, ${c.bgCard} 100%)` }}>
      <div style={{ maxWidth: 1400, margin: '0 auto' }}>
        <SectionHeader 
          label="Market Opportunity" 
          title="The $700 Billion Biodiversity Finance Gap"
          subtitle="Private nature finance surged 11x since 2020. Sovereign debt-for-nature swaps represent a $500-800B pipeline. WEII positions African nations as architects of next-generation biodiversity finance."
        />
        
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: 20, marginBottom: 48 }}>
          {[
            { value: '$700B', label: 'Annual Gap', color: c.danger },
            { value: '$102B', label: 'Private Finance 2024', color: c.success },
            { value: '$1.7T', label: 'Sustainable Debt Market', color: c.accent },
            { value: '$2.7B', label: 'BIOFIN Unlocked 2025', color: c.info },
            { value: '242M', label: 'Hectares Committed', color: c.chart1 },
            { value: '8%', label: 'Rhino Bond Return', color: c.success }
          ].map((stat, i) => (
            <Card key={i} style={{ padding: 24, textAlign: 'center' }}>
              <div style={{ fontSize: 28, fontWeight: 700, color: stat.color, marginBottom: 8 }}>{stat.value}</div>
              <div style={{ fontSize: 11, color: c.textMuted, textTransform: 'uppercase' }}>{stat.label}</div>
            </Card>
          ))}
        </div>
        
        <Card style={{ padding: 32 }}>
          <h3 style={{ fontSize: 18, fontWeight: 600, color: c.text, marginBottom: 24 }}>Nature Finance Growth Trajectory</h3>
          <ResponsiveContainer width="100%" height={300}>
            <ComposedChart data={marketData}>
              <CartesianGrid strokeDasharray="3 3" stroke={c.border} />
              <XAxis dataKey="name" stroke={c.textMuted} fontSize={12} />
              <YAxis stroke={c.textMuted} fontSize={12} />
              <Tooltip contentStyle={{ background: c.bgCard, border: `1px solid ${c.border}`, borderRadius: 8 }} />
              <Legend />
              <Bar dataKey="private" name="Private Finance ($B)" fill={c.chart1} radius={[4, 4, 0, 0]} />
              <Bar dataKey="sovereign" name="Sovereign Deals ($M)" fill={c.accent} radius={[4, 4, 0, 0]} />
              <Line type="monotone" dataKey="gap" name="Annual Gap ($B)" stroke={c.danger} strokeWidth={2} strokeDasharray="5 5" />
            </ComposedChart>
          </ResponsiveContainer>
        </Card>
      </div>
    </section>
  );
};

// ===================== MAIN SECTIONS =====================
const Hero = ({ onNavigate }) => (
  <section style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', padding: '100px 24px 60px', position: 'relative', overflow: 'hidden' }}>
    <div style={{ position: 'absolute', inset: 0, background: `radial-gradient(ellipse at 20% 30%, ${c.primary}20 0%, transparent 50%), radial-gradient(ellipse at 80% 70%, ${c.accent}10 0%, transparent 50%)` }} />
    
    <div style={{ maxWidth: 1400, margin: '0 auto', width: '100%', position: 'relative', zIndex: 1 }}>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(400px, 1fr))', gap: 60, alignItems: 'center' }}>
        <div>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '6px 14px', background: `${c.accent}20`, border: `1px solid ${c.accent}40`, borderRadius: 20, fontSize: 11, fontWeight: 700, color: c.accent, textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: 20 }}>
            <span style={{ width: 6, height: 6, background: c.accent, borderRadius: '50%' }} />
            ALU School of Wildlife Conservation • November 2025
          </div>
          
          <h1 style={{ fontSize: 'clamp(2rem, 5vw, 3.5rem)', fontWeight: 700, lineHeight: 1.1, marginBottom: 20, color: c.text }}>
            Wildlife Economy <span style={{ color: c.primary }}>Investment Index</span>
            <br />
            <span style={{ color: c.accent }}>Sovereign Debt Integration</span>
          </h1>
          
          <p style={{ fontSize: 18, color: c.textMuted, marginBottom: 28, maxWidth: 560, lineHeight: 1.7 }}>
            A comprehensive legal, policy, and institutional framework transforming WEII from a diagnostic tool into an <strong style={{ color: c.text }}>investable mechanism</strong> that aligns fiscal incentives with conservation outcomes for Tanzania and South Africa.
          </p>
          
          <div style={{ display: 'flex', gap: 28, marginBottom: 36, flexWrap: 'wrap' }}>
            {[{ v: '$700B', l: 'Finance Gap' }, { v: '63.12', l: 'SA WEII Score' }, { v: '38%', l: 'TZ Protected' }, { v: '$101K', l: 'Pilot Budget' }].map((s, i) => (
              <div key={i}>
                <div style={{ fontSize: 28, fontWeight: 700, color: i === 0 ? c.danger : c.primary }}>{s.v}</div>
                <div style={{ fontSize: 11, color: c.textMuted, textTransform: 'uppercase' }}>{s.l}</div>
              </div>
            ))}
          </div>
          
          <div style={{ display: 'flex', gap: 14, flexWrap: 'wrap' }}>
            <button onClick={() => onNavigate('calculator')} style={{ padding: '14px 28px', background: `linear-gradient(135deg, ${c.primary} 0%, ${c.primaryLight} 100%)`, color: 'white', border: 'none', borderRadius: 10, fontSize: 15, fontWeight: 600, cursor: 'pointer', boxShadow: `0 4px 20px ${c.primary}50` }}>
              Calculate Bond Impact →
            </button>
            <button onClick={() => onNavigate('framework')} style={{ padding: '14px 28px', background: 'transparent', color: c.text, border: `1px solid ${c.border}`, borderRadius: 10, fontSize: 15, fontWeight: 600, cursor: 'pointer' }}>
              View Framework
            </button>
          </div>
        </div>
        
        <div style={{ display: 'flex', justifyContent: 'center', position: 'relative' }}>
          <div style={{ position: 'relative' }}>
            <ProgressRing value={68.66} size={220} strokeWidth={16} color={c.primary} />
            <div style={{ position: 'absolute', top: -20, right: -40, background: c.bgCard, border: `1px solid ${c.border}`, borderRadius: 12, padding: '12px 16px' }}>
              <div style={{ fontSize: 14 }}>🇿🇦</div>
              <div style={{ fontSize: 18, fontWeight: 700, color: c.text }}>63.12</div>
              <div style={{ fontSize: 9, color: c.textMuted }}>Rank #1</div>
            </div>
            <div style={{ position: 'absolute', bottom: -10, left: -50, background: c.bgCard, border: `1px solid ${c.border}`, borderRadius: 12, padding: '12px 16px' }}>
              <div style={{ fontSize: 14 }}>🇹🇿</div>
              <div style={{ fontSize: 18, fontWeight: 700, color: c.text }}>52.80</div>
              <div style={{ fontSize: 9, color: c.textMuted }}>Rank #4</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const CountryComparison = () => {
  const [selected, setSelected] = useState('southAfrica');
  const country = COUNTRIES[selected];
  
  const radarData = [
    { subject: 'Wildlife', SA: 58, TZ: 43.94 },
    { subject: 'Management', SA: 74.92, TZ: 62 },
    { subject: 'Business', SA: 65, TZ: 48 },
    { subject: 'Capacity', SA: 70, TZ: 52 },
    { subject: 'Safety', SA: 68, TZ: 55 }
  ];
  
  return (
    <section id="countries" style={{ padding: '80px 24px' }}>
      <div style={{ maxWidth: 1400, margin: '0 auto' }}>
        <SectionHeader label="Country Analysis" title="Tanzania & South Africa: Dual Pilot Framework"
          subtitle="Two complementary contexts enabling cross-learning between an emerging biodiversity financier (Tanzania) and an advanced sustainable finance market (South Africa)." />
        
        <div style={{ display: 'flex', gap: 12, marginBottom: 32, justifyContent: 'center' }}>
          {Object.entries(COUNTRIES).map(([key, c]) => (
            <button key={key} onClick={() => setSelected(key)} style={{ padding: '10px 24px', background: selected === key ? `${c.primary}30` : 'transparent',
              border: `1px solid ${selected === key ? c.primary : c.border}`, borderRadius: 8, color: selected === key ? c.text : c.textMuted, fontSize: 14, fontWeight: 500, cursor: 'pointer' }}>
              {COUNTRIES[key].flag} {COUNTRIES[key].name}
            </button>
          ))}
        </div>
        
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(400px, 1fr))', gap: 32 }}>
          <Card style={{ padding: 32 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 24 }}>
              <div>
                <div style={{ fontSize: 48, marginBottom: 8 }}>{country.flag}</div>
                <h3 style={{ fontSize: 28, fontWeight: 700, color: c.text }}>{country.name}</h3>
                <div style={{ fontSize: 14, color: c.textMuted }}>{country.region} • WEII Rank #{country.rank}</div>
              </div>
              <ProgressRing value={country.weiiScore} size={100} strokeWidth={8} />
            </div>
            
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12, marginBottom: 24 }}>
              {[
                { v: `${country.debtToGDP}%`, l: 'Debt/GDP', warn: country.debtToGDP > 60 },
                { v: `${country.protectedArea}%`, l: 'Protected', good: country.protectedArea > 20 },
                { v: `${country.gdpGrowth}%`, l: 'GDP Growth' }
              ].map((s, i) => (
                <div key={i} style={{ textAlign: 'center', padding: 16, background: c.bg, borderRadius: 10 }}>
                  <div style={{ fontSize: 20, fontWeight: 700, color: s.warn ? c.warning : s.good ? c.success : c.text }}>{s.v}</div>
                  <div style={{ fontSize: 10, color: c.textMuted, textTransform: 'uppercase' }}>{s.l}</div>
                </div>
              ))}
            </div>
            
            <div style={{ marginBottom: 24 }}>
              <div style={{ fontSize: 12, fontWeight: 600, color: c.textMuted, marginBottom: 12, textTransform: 'uppercase' }}>Key Wildlife Populations</div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12 }}>
                <div style={{ textAlign: 'center' }}><span style={{ fontSize: 20 }}>🦁</span><div style={{ fontSize: 16, fontWeight: 700, color: c.text }}>{country.lionPop.toLocaleString()}</div><div style={{ fontSize: 10, color: c.textMuted }}>Lions</div></div>
                <div style={{ textAlign: 'center' }}><span style={{ fontSize: 20 }}>🐃</span><div style={{ fontSize: 16, fontWeight: 700, color: c.text }}>{country.buffaloPop.toLocaleString()}</div><div style={{ fontSize: 10, color: c.textMuted }}>Buffalo</div></div>
                <div style={{ textAlign: 'center' }}><span style={{ fontSize: 20 }}>🦏</span><div style={{ fontSize: 16, fontWeight: 700, color: c.text }}>{country.rhinoPop.toLocaleString()}</div><div style={{ fontSize: 10, color: c.textMuted }}>Rhinos</div></div>
              </div>
            </div>
            
            <div style={{ marginBottom: 20 }}>
              <div style={{ fontSize: 12, fontWeight: 600, color: c.textMuted, marginBottom: 10, textTransform: 'uppercase' }}>Key Highlights</div>
              {country.highlights.slice(0, 4).map((h, i) => (
                <div key={i} style={{ display: 'flex', alignItems: 'flex-start', gap: 8, fontSize: 13, color: c.textMuted, marginBottom: 6 }}>
                  <span style={{ color: c.success }}>✓</span> {h}
                </div>
              ))}
            </div>
            
            <div>
              <div style={{ fontSize: 12, fontWeight: 600, color: c.textMuted, marginBottom: 10, textTransform: 'uppercase' }}>Enabling Legislation</div>
              <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                {country.keyLaws.map((law, i) => (
                  <span key={i} style={{ padding: '4px 10px', background: c.bg, borderRadius: 6, fontSize: 11, color: c.textMuted }}>{law}</span>
                ))}
              </div>
            </div>
          </Card>
          
          <Card style={{ padding: 32 }}>
            <h4 style={{ fontSize: 16, fontWeight: 600, color: c.text, marginBottom: 20 }}>WEII Component Comparison</h4>
            <ResponsiveContainer width="100%" height={300}>
              <RadarChart data={radarData}>
                <PolarGrid stroke={c.border} />
                <PolarAngleAxis dataKey="subject" tick={{ fill: c.textMuted, fontSize: 11 }} />
                <PolarRadiusAxis angle={30} domain={[0, 100]} tick={{ fill: c.textDim, fontSize: 9 }} />
                <Radar name="South Africa" dataKey="SA" stroke={c.chart1} fill={c.chart1} fillOpacity={0.3} />
                <Radar name="Tanzania" dataKey="TZ" stroke={c.accent} fill={c.accent} fillOpacity={0.3} />
                <Legend />
              </RadarChart>
            </ResponsiveContainer>
            
            <div style={{ marginTop: 24, padding: 16, background: c.bg, borderRadius: 10 }}>
              <div style={{ fontSize: 12, fontWeight: 600, color: c.text, marginBottom: 8 }}>💡 Bond Structure Potential</div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16 }}>
                <div><div style={{ fontSize: 18, fontWeight: 700, color: c.accent }}>${country.bondPotential.size}M</div><div style={{ fontSize: 10, color: c.textMuted }}>Target Size</div></div>
                <div><div style={{ fontSize: 18, fontWeight: 700, color: c.text }}>{country.bondPotential.couponBase}%</div><div style={{ fontSize: 10, color: c.textMuted }}>Base Coupon</div></div>
                <div><div style={{ fontSize: 18, fontWeight: 700, color: c.success }}>±{country.bondPotential.stepDown}bp</div><div style={{ fontSize: 10, color: c.textMuted }}>Adjustment</div></div>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </section>
  );
};

const BenchmarkDeals = () => {
  const [expanded, setExpanded] = useState(null);
  return (
    <section id="benchmarks" style={{ padding: '80px 24px', background: c.bgCard }}>
      <div style={{ maxWidth: 1400, margin: '0 auto' }}>
        <SectionHeader label="Global Precedents" title="Benchmark Nature-Linked Transactions"
          subtitle="Learning from $4B+ in pioneering biodiversity finance deals that demonstrate technical feasibility and strong investor appetite." />
        
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          {BENCHMARK_DEALS.map((deal, i) => (
            <Card key={i} style={{ overflow: 'hidden' }}>
              <div onClick={() => setExpanded(expanded === i ? null : i)} style={{ padding: 24, cursor: 'pointer', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 16 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
                  <div style={{ width: 56, height: 56, background: c.bg, borderRadius: 14, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 28 }}>{deal.icon}</div>
                  <div>
                    <h4 style={{ fontSize: 16, fontWeight: 600, color: c.text, marginBottom: 2 }}>{deal.name}</h4>
                    <div style={{ fontSize: 13, color: c.textMuted }}>{deal.issuer} • {deal.country} • {deal.year}</div>
                  </div>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 24 }}>
                  <div style={{ textAlign: 'right' }}>
                    <div style={{ fontSize: 24, fontWeight: 700, color: c.text }}>${deal.size}M</div>
                    <Badge type={deal.status}>{deal.status}</Badge>
                  </div>
                  <span style={{ color: c.textMuted, transform: expanded === i ? 'rotate(180deg)' : 'none', transition: 'transform 0.3s' }}>▼</span>
                </div>
              </div>
              {expanded === i && (
                <div style={{ padding: '0 24px 24px', borderTop: `1px solid ${c.border}`, paddingTop: 24 }}>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 16, marginBottom: 20 }}>
                    {[{ l: 'Type', v: deal.type }, { l: 'KPI', v: deal.kpi }, { l: 'Target', v: deal.target }, { l: 'Achieved', v: deal.achieved }, { l: 'Verifier', v: deal.verifier }, { l: 'Mechanism', v: deal.mechanism }].map((item, j) => (
                      <div key={j} style={{ background: c.bg, padding: 14, borderRadius: 8 }}>
                        <div style={{ fontSize: 10, color: c.textMuted, textTransform: 'uppercase', marginBottom: 4 }}>{item.l}</div>
                        <div style={{ fontSize: 13, color: c.text, fontWeight: 500 }}>{item.v}</div>
                      </div>
                    ))}
                  </div>
                  <div style={{ padding: 14, background: `${c.accent}15`, borderRadius: 8, borderLeft: `3px solid ${c.accent}` }}>
                    <div style={{ fontSize: 12, fontWeight: 600, color: c.accent, marginBottom: 4 }}>Key Lesson for WEII</div>
                    <div style={{ fontSize: 13, color: c.textMuted }}>{deal.lessons}</div>
                  </div>
                </div>
              )}
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

const FivePillarFramework = () => (
  <section id="framework" style={{ padding: '80px 24px' }}>
    <div style={{ maxWidth: 1400, margin: '0 auto' }}>
      <SectionHeader label="Integration Framework" title="Five-Pillar WEII Integration Architecture"
        subtitle="A comprehensive framework moving WEII from diagnostic index to credible, investable architecture for sovereign biodiversity finance." />
      
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: 20 }}>
        {FIVE_PILLAR_FRAMEWORK.map((pillar, i) => (
          <Card key={i} style={{ padding: 28, position: 'relative', overflow: 'hidden' }}>
            <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 4, background: `linear-gradient(90deg, ${c.primary}, ${c.accent})` }} />
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 16 }}>
              <div style={{ width: 48, height: 48, background: c.bg, borderRadius: 12, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 24 }}>{pillar.icon}</div>
              <div>
                <div style={{ fontSize: 11, color: c.textMuted }}>PILLAR {pillar.pillar}</div>
                <div style={{ fontSize: 16, fontWeight: 600, color: c.text }}>{pillar.name}</div>
              </div>
            </div>
            <Badge type={pillar.status} size="md">{pillar.status}</Badge>
            <div style={{ marginTop: 20 }}>
              <div style={{ fontSize: 11, color: c.textMuted, marginBottom: 6 }}>🇹🇿 Tanzania</div>
              <div style={{ fontSize: 13, color: c.text, marginBottom: 12 }}>{pillar.tz}</div>
              <div style={{ fontSize: 11, color: c.textMuted, marginBottom: 6 }}>🇿🇦 South Africa</div>
              <div style={{ fontSize: 13, color: c.text, marginBottom: 16 }}>{pillar.za}</div>
            </div>
            <div style={{ padding: 12, background: c.bg, borderRadius: 8, fontSize: 12, color: c.textMuted }}>
              <strong style={{ color: c.accent }}>Action:</strong> {pillar.action}
            </div>
          </Card>
        ))}
      </div>
    </div>
  </section>
);

const RiskMatrix = () => (
  <section id="risks" style={{ padding: '80px 24px', background: c.bgCard }}>
    <div style={{ maxWidth: 1400, margin: '0 auto' }}>
      <SectionHeader label="Risk Assessment" title="Comprehensive Risk Register & Mitigation"
        subtitle="Structured risk management with contingency protocols ensuring project resilience across political, technical, market, and social dimensions." />
      
      <div style={{ overflowX: 'auto' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: 800 }}>
          <thead>
            <tr style={{ background: c.bg }}>
              {['Risk', 'Category', 'L', 'I', 'Mitigation Strategy', 'Contingency'].map(h => (
                <th key={h} style={{ padding: 16, textAlign: 'left', fontSize: 11, fontWeight: 600, color: c.textMuted, textTransform: 'uppercase', borderBottom: `1px solid ${c.border}` }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {RISKS.map((r, i) => (
              <tr key={i} style={{ borderBottom: `1px solid ${c.border}` }}>
                <td style={{ padding: 16 }}><div style={{ fontWeight: 600, color: c.text, fontSize: 14 }}>{r.name}</div></td>
                <td style={{ padding: 16 }}><Badge>{r.category}</Badge></td>
                <td style={{ padding: 16 }}><Badge type={r.likelihood}>{r.likelihood[0]}</Badge></td>
                <td style={{ padding: 16 }}><Badge type={r.impact}>{r.impact[0]}</Badge></td>
                <td style={{ padding: 16, fontSize: 13, color: c.textMuted, maxWidth: 280 }}>{r.mitigation}</td>
                <td style={{ padding: 16, fontSize: 12, color: c.textDim, maxWidth: 200 }}>{r.contingency}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  </section>
);

const Implementation = () => (
  <section id="implementation" style={{ padding: '80px 24px' }}>
    <div style={{ maxWidth: 1400, margin: '0 auto' }}>
      <SectionHeader label="Implementation" title="6-Month Phased Roadmap"
        subtitle="Completed feasibility study with $101,000 budget establishing market-ready foundation for pilot issuance." />
      
      <div style={{ display: 'flex', gap: 16, overflowX: 'auto', padding: '10px 0' }}>
        {IMPLEMENTATION_PHASES.map((phase, i) => (
          <Card key={i} style={{ minWidth: 260, padding: 24, flex: '0 0 auto' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16 }}>
              <div style={{ width: 44, height: 44, background: `linear-gradient(135deg, ${c.primary}, ${c.primaryLight})`, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18, fontWeight: 700, color: 'white' }}>{phase.phase}</div>
              <Badge type={phase.status}>{phase.status}</Badge>
            </div>
            <h4 style={{ fontSize: 15, fontWeight: 600, color: c.text, marginBottom: 6 }}>{phase.name}</h4>
            <div style={{ fontSize: 13, color: c.accent, marginBottom: 16 }}>Months {phase.months}</div>
            <ul style={{ listStyle: 'none', padding: 0, margin: 0, marginBottom: 20 }}>
              {phase.deliverables.map((d, j) => (
                <li key={j} style={{ fontSize: 12, color: c.textMuted, marginBottom: 6, paddingLeft: 14, position: 'relative' }}>
                  <span style={{ position: 'absolute', left: 0, color: c.success }}>✓</span> {d}
                </li>
              ))}
            </ul>
            <div style={{ paddingTop: 16, borderTop: `1px solid ${c.border}`, display: 'flex', justifyContent: 'space-between' }}>
              <span style={{ fontSize: 12, color: c.textMuted }}>Budget</span>
              <span style={{ fontSize: 14, fontWeight: 600, color: c.text }}>${(phase.budget / 1000).toFixed(0)}K</span>
            </div>
            <div style={{ marginTop: 12, height: 6, background: c.bg, borderRadius: 3, overflow: 'hidden' }}>
              <div style={{ width: `${phase.progress}%`, height: '100%', background: `linear-gradient(90deg, ${c.primary}, ${c.success})`, borderRadius: 3 }} />
            </div>
          </Card>
        ))}
      </div>
      
      <Card style={{ marginTop: 32, padding: 24, display: 'flex', justifyContent: 'space-around', alignItems: 'center', flexWrap: 'wrap', gap: 24 }}>
        <StatBox value="$101K" label="Total Budget" color={c.text} />
        <StatBox value="6" label="Months" color={c.accent} />
        <StatBox value="5" label="Phases Complete" color={c.success} />
        <StatBox value="Nov 2025" label="Submitted" color={c.info} />
      </Card>
    </div>
  </section>
);

const Contact = () => (
  <section id="contact" style={{ padding: '80px 24px', background: c.bgCard }}>
    <div style={{ maxWidth: 600, margin: '0 auto', textAlign: 'center' }}>
      <SectionHeader label="Connect" title="Partner with the WEII Initiative"
        subtitle="Join us in pioneering the integration of biodiversity metrics into sovereign finance." />
      
      <Card style={{ padding: 40 }} glow>
        <h3 style={{ fontSize: 22, fontWeight: 700, color: c.text, marginBottom: 12 }}>Research Lead</h3>
        <p style={{ fontSize: 20, color: c.primary, fontWeight: 600, marginBottom: 4 }}>Maximillian Msack</p>
        <p style={{ fontSize: 14, color: c.textMuted, marginBottom: 20 }}>MBA Candidate • African Leadership University</p>
        
        <a href="mailto:m.msack@mba.alusb.com" style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '14px 28px', background: `linear-gradient(135deg, ${c.primary}, ${c.primaryLight})`, color: 'white', textDecoration: 'none', borderRadius: 10, fontSize: 15, fontWeight: 600 }}>
          ✉️ m.msack@mba.alusb.com
        </a>
        
        <div style={{ marginTop: 32, paddingTop: 32, borderTop: `1px solid ${c.border}` }}>
          <p style={{ fontSize: 12, color: c.textMuted, marginBottom: 8 }}>Academic Supervisor</p>
          <p style={{ fontSize: 16, color: c.text, fontWeight: 500 }}>Dr. Sue Snyman</p>
          <p style={{ fontSize: 13, color: c.textMuted }}>Director of Research, ALU School of Wildlife Conservation</p>
        </div>
      </Card>
    </div>
  </section>
);

const Footer = () => (
  <footer style={{ background: c.bg, borderTop: `1px solid ${c.border}`, padding: '40px 24px 24px' }}>
    <div style={{ maxWidth: 1400, margin: '0 auto', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 16 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <div style={{ width: 40, height: 40, background: `linear-gradient(135deg, ${c.primary}, ${c.primaryLight})`, borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20 }}>🦁</div>
        <div>
          <div style={{ fontSize: 18, fontWeight: 700, color: c.text }}>WEII</div>
          <div style={{ fontSize: 10, color: c.textMuted }}>Wildlife Economy Investment Index</div>
        </div>
      </div>
      <div style={{ fontSize: 12, color: c.textMuted }}>
        © 2025 African Leadership University • School of Wildlife Conservation • Capstone Submitted November 2025
      </div>
    </div>
  </footer>
);

// ===================== MAIN APP =====================
export default function WEIIPlatform() {
  const [section, setSection] = useState('hero');
  const [scrolled, setScrolled] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => { setTimeout(() => setLoading(false), 1200); }, []);
  useEffect(() => {
    const h = () => setScrolled(window.scrollY > 60);
    window.addEventListener('scroll', h);
    return () => window.removeEventListener('scroll', h);
  }, []);

  const nav = (id) => { setSection(id); document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' }); };

  if (loading) return (
    <div style={{ position: 'fixed', inset: 0, background: c.bg, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <div style={{ textAlign: 'center' }}>
        <div style={{ fontSize: 48, fontWeight: 700, background: `linear-gradient(135deg, ${c.primary}, ${c.accent})`, WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', marginBottom: 16 }}>WEII</div>
        <div style={{ fontSize: 13, color: c.textMuted }}>Wildlife Economy Investment Index</div>
      </div>
    </div>
  );

  return (
    <div style={{ fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif', background: c.bg, color: c.text, minHeight: '100vh' }}>
      <header style={{ position: 'fixed', top: 0, left: 0, right: 0, zIndex: 1000, padding: '0 24px', background: scrolled ? `${c.bg}f5` : 'transparent', backdropFilter: scrolled ? 'blur(16px)' : 'none', borderBottom: scrolled ? `1px solid ${c.border}` : 'none', transition: 'all 0.3s' }}>
        <div style={{ maxWidth: 1400, margin: '0 auto', display: 'flex', alignItems: 'center', justifyContent: 'space-between', height: 70 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer' }} onClick={() => nav('hero')}>
            <div style={{ width: 38, height: 38, background: `linear-gradient(135deg, ${c.primary}, ${c.primaryLight})`, borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18 }}>🦁</div>
            <div>
              <div style={{ fontSize: 18, fontWeight: 700, color: c.text }}>WEII</div>
              <div style={{ fontSize: 8, color: c.textMuted, textTransform: 'uppercase', letterSpacing: '0.1em' }}>Sovereign Debt Integration</div>
            </div>
          </div>
          <nav style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
            {[{ id: 'hero', l: 'Home' }, { id: 'countries', l: 'Countries' }, { id: 'benchmarks', l: 'Deals' }, { id: 'framework', l: 'Framework' }, { id: 'calculator', l: 'Calculator' }, { id: 'risks', l: 'Risks' }].map(n => (
              <button key={n.id} onClick={() => nav(n.id)} style={{ padding: '8px 14px', background: section === n.id ? `${c.primary}30` : 'transparent', border: 'none', borderRadius: 6, fontSize: 12, fontWeight: 500, color: section === n.id ? c.text : c.textMuted, cursor: 'pointer' }}>{n.l}</button>
            ))}
            <button onClick={() => nav('contact')} style={{ padding: '8px 18px', background: `linear-gradient(135deg, ${c.primary}, ${c.primaryLight})`, border: 'none', borderRadius: 6, fontSize: 12, fontWeight: 600, color: 'white', cursor: 'pointer', marginLeft: 8 }}>Connect</button>
          </nav>
        </div>
      </header>

      <main>
        <div id="hero"><Hero onNavigate={nav} /></div>
        <MarketOpportunity />
        <div id="countries"><CountryComparison /></div>
        <div id="benchmarks"><BenchmarkDeals /></div>
        <div id="framework"><FivePillarFramework /></div>
        <div id="calculator" style={{ padding: '80px 24px', background: c.bgCard }}>
          <div style={{ maxWidth: 1400, margin: '0 auto' }}>
            <SectionHeader label="Investment Tool" title="WEII-Linked Bond Calculator"
              subtitle="Model the fiscal impact of biodiversity-linked sovereign debt with customizable parameters." />
            <BondCalculator />
          </div>
        </div>
        <div id="risks"><RiskMatrix /></div>
        <div id="implementation"><Implementation /></div>
        <div id="contact"><Contact /></div>
      </main>
      <Footer />
    </div>
  );
}
